
import React from "react";
import { useParams } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import { getProductsByCategory } from "@/data/products";

const getCategoryTitle = (slug: string) => {
  switch (slug) {
    case "paper":
      return "Paper Products";
    case "wood":
      return "Wood Products";
    case "organic":
      return "Organic Products";
    default:
      return "Products";
  }
};

const CategoryPage = () => {
  const { category } = useParams<{ category: string }>();
  const products = getProductsByCategory(category || "");
  
  const categoryTitle = getCategoryTitle(category || "");
  
  return (
    <div className="min-h-screen flex flex-col bg-eco-background">
      <Navbar />
      <main className="flex-grow py-10">
        <div className="container mx-auto px-4">
          <div className="mb-10">
            <h1 className="text-3xl font-bold text-eco-text mb-2">{categoryTitle}</h1>
            <p className="text-gray-600">
              Explore our range of sustainable {categoryTitle.toLowerCase()} that are good for you and the planet.
            </p>
          </div>
          
          {products.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-lg text-gray-600">No products found in this category.</p>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CategoryPage;
