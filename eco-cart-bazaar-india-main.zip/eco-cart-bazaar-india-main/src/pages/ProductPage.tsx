
import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { getProductById } from "@/data/products";
import { useCart } from "@/contexts/CartContext";
import { ArrowLeft, IndianRupee } from "lucide-react";

const ProductPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  
  const product = getProductById(Number(id));
  
  if (!product) {
    return (
      <div className="min-h-screen flex flex-col bg-eco-background">
        <Navbar />
        <main className="flex-grow container mx-auto px-4 py-10">
          <Button variant="ghost" onClick={() => navigate(-1)} className="mb-6">
            <ArrowLeft className="h-4 w-4 mr-2" /> Go Back
          </Button>
          <div className="text-center py-20">
            <h1 className="text-2xl font-bold text-eco-text mb-4">Product Not Found</h1>
            <p className="text-gray-600 mb-6">The product you're looking for doesn't exist or has been removed.</p>
            <Button onClick={() => navigate("/")} className="bg-eco-primary hover:bg-eco-secondary text-white">
              Return to Home
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-eco-background">
      <Navbar />
      <main className="flex-grow container mx-auto px-4 py-10">
        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" /> Go Back
        </Button>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-80 object-contain p-4"
            />
          </div>
          
          <div>
            <h1 className="text-3xl font-bold text-eco-text mb-2">{product.name}</h1>
            <div className="flex items-center text-2xl font-bold text-eco-primary mb-4">
              <IndianRupee className="h-5 w-5 inline mr-1" />
              {product.price}
            </div>
            
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-eco-text mb-2">About this product</h2>
              <p className="text-gray-600">{product.description}</p>
            </div>
            
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-eco-text mb-2">Category</h2>
              <p className="text-gray-600 capitalize">{product.category}</p>
            </div>
            
            <Button 
              className="w-full bg-eco-primary hover:bg-eco-secondary text-white py-6"
              onClick={() => addToCart(product)}
            >
              Add to Cart
            </Button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ProductPage;
