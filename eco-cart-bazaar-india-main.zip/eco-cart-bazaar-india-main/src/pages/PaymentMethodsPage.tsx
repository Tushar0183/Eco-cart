
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PaymentMethod } from "@/types/product";
import { CreditCard, IndianRupee, Trash2, Wallet } from "lucide-react";

const paymentSchema = z.object({
  type: z.enum(["credit", "debit", "upi", "netbanking", "wallet"]),
  cardNumber: z.string().optional(),
  nameOnCard: z.string().optional(),
  expiryDate: z.string().optional(),
  cvv: z.string().optional(),
  upiId: z.string().optional(),
  walletProvider: z.string().optional(),
});

// Mock data for saved payment methods
const savedPaymentMethods: PaymentMethod[] = [
  {
    id: "1",
    type: "credit",
    name: "HDFC Credit Card",
    lastFour: "4242",
    isDefault: true,
  },
  {
    id: "2",
    type: "upi",
    name: "Google Pay",
    isDefault: false,
  },
];

const PaymentMethodsPage = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(savedPaymentMethods);
  const [showAddNew, setShowAddNew] = useState(false);
  
  const form = useForm<z.infer<typeof paymentSchema>>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      type: "credit",
    },
  });

  const paymentType = form.watch("type");

  const handleAddPayment = (values: z.infer<typeof paymentSchema>) => {
    // In a real app, you'd make an API call to save the payment method
    
    const newPaymentMethod: PaymentMethod = {
      id: Date.now().toString(),
      type: values.type,
      name: values.type === "credit" || values.type === "debit" 
        ? `${values.nameOnCard}'s ${values.type} card` 
        : values.type === "upi" 
          ? `UPI - ${values.upiId}` 
          : `${values.walletProvider} Wallet`,
      lastFour: values.cardNumber ? values.cardNumber.slice(-4) : undefined,
      isDefault: paymentMethods.length === 0,
    };
    
    setPaymentMethods([...paymentMethods, newPaymentMethod]);
    setShowAddNew(false);
    
    toast({
      title: "Payment Method Added",
      description: `Your ${values.type} has been added successfully.`,
    });
  };

  const deletePaymentMethod = (id: string) => {
    setPaymentMethods(paymentMethods.filter(method => method.id !== id));
    
    toast({
      title: "Payment Method Removed",
      description: "Your payment method has been removed successfully.",
    });
  };

  const setDefaultPaymentMethod = (id: string) => {
    setPaymentMethods(paymentMethods.map(method => ({
      ...method,
      isDefault: method.id === id,
    })));
    
    toast({
      title: "Default Payment Updated",
      description: "Your default payment method has been updated.",
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-eco-background">
      <Navbar />
      <main className="flex-grow py-10">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-eco-text">Payment Methods</h1>
            <Button 
              onClick={() => setShowAddNew(!showAddNew)}
              className="bg-eco-primary hover:bg-eco-secondary text-white"
            >
              {showAddNew ? "Cancel" : "Add New"}
            </Button>
          </div>
          
          {paymentMethods.length > 0 && (
            <div className="space-y-4 mb-8">
              <h2 className="text-xl font-semibold text-eco-text">Saved Payment Methods</h2>
              {paymentMethods.map((method) => (
                <Card key={method.id} className="border border-gray-200">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center">
                        <div className="bg-eco-primary/10 p-3 rounded-full mr-4">
                          {method.type === "credit" || method.type === "debit" ? (
                            <CreditCard className="h-6 w-6 text-eco-primary" />
                          ) : (
                            <Wallet className="h-6 w-6 text-eco-primary" />
                          )}
                        </div>
                        <div>
                          <h3 className="font-medium">{method.name}</h3>
                          {method.lastFour && (
                            <p className="text-sm text-gray-500">•••• {method.lastFour}</p>
                          )}
                          {method.isDefault && (
                            <span className="text-xs bg-eco-primary/10 text-eco-primary px-2 py-1 rounded-full mt-1 inline-block">
                              Default
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        {!method.isDefault && (
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => setDefaultPaymentMethod(method.id)}
                          >
                            Set Default
                          </Button>
                        )}
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => deletePaymentMethod(method.id)}
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
          
          {showAddNew && (
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <h2 className="text-xl font-semibold text-eco-text mb-6">Add Payment Method</h2>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleAddPayment)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>Payment Type</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex flex-wrap gap-4"
                          >
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="credit" id="credit" />
                              <FormLabel htmlFor="credit" className="font-normal cursor-pointer">
                                Credit Card
                              </FormLabel>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="debit" id="debit" />
                              <FormLabel htmlFor="debit" className="font-normal cursor-pointer">
                                Debit Card
                              </FormLabel>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="upi" id="upi" />
                              <FormLabel htmlFor="upi" className="font-normal cursor-pointer">
                                UPI
                              </FormLabel>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="netbanking" id="netbanking" />
                              <FormLabel htmlFor="netbanking" className="font-normal cursor-pointer">
                                Net Banking
                              </FormLabel>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="wallet" id="wallet" />
                              <FormLabel htmlFor="wallet" className="font-normal cursor-pointer">
                                Wallet
                              </FormLabel>
                            </div>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {(paymentType === "credit" || paymentType === "debit") && (
                    <>
                      <FormField
                        control={form.control}
                        name="cardNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Card Number</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <span className="absolute left-3 top-3 text-gray-400">
                                  <CreditCard className="h-4 w-4" />
                                </span>
                                <Input 
                                  className="pl-10" 
                                  placeholder="XXXX XXXX XXXX XXXX" 
                                  {...field} 
                                />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="nameOnCard"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Name on Card</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter name as on card" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="expiryDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Expiry Date</FormLabel>
                              <FormControl>
                                <Input placeholder="MM/YY" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="cvv"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>CVV</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="XXX" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </>
                  )}
                  
                  {paymentType === "upi" && (
                    <FormField
                      control={form.control}
                      name="upiId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>UPI ID</FormLabel>
                          <FormControl>
                            <Input placeholder="username@upi" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  
                  {paymentType === "wallet" && (
                    <FormField
                      control={form.control}
                      name="walletProvider"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Wallet Provider</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Paytm, PhonePe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-eco-primary hover:bg-eco-secondary text-white"
                  >
                    Save Payment Method
                  </Button>
                </form>
              </Form>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default PaymentMethodsPage;
