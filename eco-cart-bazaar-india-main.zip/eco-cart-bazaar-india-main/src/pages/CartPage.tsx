
import React from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import CartItem from "@/components/CartItem";
import { useCart } from "@/contexts/CartContext";
import { ShoppingCart, IndianRupee } from "lucide-react";

const CartPage = () => {
  const { cartItems, clearCart, getCartTotal } = useCart();
  
  return (
    <div className="min-h-screen flex flex-col bg-eco-background">
      <Navbar />
      <main className="flex-grow container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold text-eco-text mb-6">Your Cart</h1>
        
        {cartItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
                {cartItems.map((item) => (
                  <CartItem key={item.id} item={item} />
                ))}
                
                <div className="mt-6 pt-4 border-t border-gray-200 flex justify-between items-center">
                  <Button 
                    variant="outline" 
                    className="text-red-500 border-red-500 hover:bg-red-50 hover:text-red-600"
                    onClick={clearCart}
                  >
                    Clear Cart
                  </Button>
                  
                  <Link to="/">
                    <Button variant="link" className="text-eco-primary hover:text-eco-secondary">
                      Continue Shopping
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
            
            <div>
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6 sticky top-20">
                <h2 className="text-xl font-bold text-eco-text mb-4">Order Summary</h2>
                
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Items ({cartItems.length}):</span>
                    <div className="flex items-center font-medium">
                      <IndianRupee className="h-3.5 w-3.5 mr-1" />
                      {getCartTotal()}
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Shipping:</span>
                    <span className="text-green-600">Free</span>
                  </div>
                </div>
                
                <div className="border-t border-gray-200 pt-4 mb-6">
                  <div className="flex justify-between items-center text-lg font-bold">
                    <span>Total:</span>
                    <div className="flex items-center text-eco-primary">
                      <IndianRupee className="h-4 w-4 mr-1" />
                      {getCartTotal()}
                    </div>
                  </div>
                </div>
                
                <Button className="w-full bg-eco-primary hover:bg-eco-secondary text-white">
                  Proceed to Checkout
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-lg shadow-sm border border-gray-100">
            <ShoppingCart className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h2 className="text-2xl font-bold text-eco-text mb-2">Your cart is empty</h2>
            <p className="text-gray-600 mb-6">Looks like you haven't added any products to your cart yet.</p>
            <Link to="/">
              <Button className="bg-eco-primary hover:bg-eco-secondary text-white">
                Start Shopping
              </Button>
            </Link>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default CartPage;
