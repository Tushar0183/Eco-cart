
import React from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Hero from "@/components/Hero";
import CategorySection from "@/components/CategorySection";
import { getProductsByCategory } from "@/data/products";

const Index = () => {
  const paperProducts = getProductsByCategory("paper");
  const woodProducts = getProductsByCategory("wood");
  const organicProducts = getProductsByCategory("organic");

  return (
    <div className="min-h-screen flex flex-col bg-eco-background">
      <Navbar />
      <main className="flex-grow">
        <Hero />
        
        <div className="py-8">
          <CategorySection title="Paper Products" categorySlug="paper" products={paperProducts} />
          <CategorySection title="Wood Products" categorySlug="wood" products={woodProducts} />
          <CategorySection title="Organic Products" categorySlug="organic" products={organicProducts} />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Index;
