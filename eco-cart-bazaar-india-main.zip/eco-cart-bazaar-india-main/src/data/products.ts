
import { Product } from "@/types/product";

export const products: Product[] = [
  // Paper Products
  {
    id: 1,
    name: "Recycled Notebooks",
    description: "Set of 3 eco-friendly notebooks made from 100% recycled paper with seed-infused covers that can be planted after use.",
    price: 349,
    category: "paper",
    image: "https://images.unsplash.com/photo-1618160702438-9b02ab6515c9?w=500&auto=format&fit=crop"
  },
  {
    id: 2,
    name: "Bamboo Toilet Paper",
    description: "Ultra-soft, tree-free toilet paper made from sustainable bamboo fibers. Plastic-free packaging.",
    price: 299,
    category: "paper",
    image: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=500&auto=format&fit=crop"
  },
  {
    id: 3,
    name: "Biodegradable Gift Wrap",
    description: "Beautiful gift wrapping paper made from recycled materials with vegetable-based inks. Fully compostable.",
    price: 199,
    category: "paper",
    image: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=500&auto=format&fit=crop"
  },
  {
    id: 4,
    name: "Recycled Paper Bags",
    description: "Pack of 10 sturdy shopping bags made from recycled kraft paper with twisted paper handles.",
    price: 249,
    category: "paper",
    image: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=500&auto=format&fit=crop"
  },
  
  // Wood Products
  {
    id: 5,
    name: "Bamboo Cutlery Set",
    description: "Reusable bamboo utensil set including fork, knife, spoon, and chopsticks in a cotton carry pouch.",
    price: 599,
    category: "wood",
    image: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=500&auto=format&fit=crop"
  },
  {
    id: 6,
    name: "Wooden Phone Stand",
    description: "Handcrafted phone stand made from sustainable Indian rosewood. Each piece is unique with natural wood grain patterns.",
    price: 499,
    category: "wood",
    image: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=500&auto=format&fit=crop"
  },
  {
    id: 7,
    name: "Bamboo Toothbrush",
    description: "Set of 4 biodegradable toothbrushes with bamboo handles and BPA-free nylon bristles.",
    price: 249,
    category: "wood",
    image: "https://images.unsplash.com/photo-1618160702438-9b02ab6515c9?w=500&auto=format&fit=crop"
  },
  {
    id: 8,
    name: "Wooden Kitchen Utensils",
    description: "5-piece set of cooking utensils made from sustainably harvested neem wood, naturally antibacterial.",
    price: 899,
    category: "wood",
    image: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=500&auto=format&fit=crop"
  },

  // Organic Products
  {
    id: 9,
    name: "Organic Cotton Tote Bag",
    description: "Durable and washable tote bag made from GOTS certified organic cotton. Perfect for grocery shopping.",
    price: 399,
    category: "organic",
    image: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=500&auto=format&fit=crop"
  },
  {
    id: 10,
    name: "Natural Loofah Scrubbers",
    description: "Set of 3 plastic-free bath and kitchen scrubbers grown organically without pesticides.",
    price: 299,
    category: "organic",
    image: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=500&auto=format&fit=crop"
  },
  {
    id: 11,
    name: "Organic Beeswax Wraps",
    description: "Reusable food wraps made with organic cotton, beeswax, jojoba oil and tree resin. Replaces plastic wrap.",
    price: 549,
    category: "organic",
    image: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=500&auto=format&fit=crop"
  },
  {
    id: 12,
    name: "Hemp Yoga Mat",
    description: "Non-slip yoga mat made from sustainable hemp fibers with natural rubber backing. Free from PVC and toxic chemicals.",
    price: 1499,
    category: "organic",
    image: "https://images.unsplash.com/photo-1618160702438-9b02ab6515c9?w=500&auto=format&fit=crop"
  }
];

export const getProductsByCategory = (category: string) => {
  return products.filter(product => product.category === category);
};

export const getProductById = (id: number) => {
  return products.find(product => product.id === id);
};
