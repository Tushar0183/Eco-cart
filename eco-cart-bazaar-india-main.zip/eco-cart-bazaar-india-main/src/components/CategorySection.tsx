
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import ProductCard from "@/components/ProductCard";
import { Product } from "@/types/product";

interface CategorySectionProps {
  title: string;
  categorySlug: string;
  products: Product[];
}

const CategorySection: React.FC<CategorySectionProps> = ({ title, categorySlug, products }) => {
  return (
    <section className="py-10">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-eco-text">{title}</h2>
          <Link to={`/category/${categorySlug}`}>
            <Button variant="link" className="text-eco-primary hover:text-eco-secondary">
              View All →
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategorySection;
