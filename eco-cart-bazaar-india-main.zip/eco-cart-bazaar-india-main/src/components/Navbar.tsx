
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ShoppingCart, User } from "lucide-react";
import { useCart } from "@/contexts/CartContext";

const Navbar = () => {
  const { getCartItemCount } = useCart();
  
  return (
    <header className="sticky top-0 z-10 bg-eco-background border-b border-eco-primary/10">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-eco-primary">
          EcoBazaar
        </Link>
        
        <nav className="hidden md:flex items-center space-x-6">
          <Link to="/" className="text-eco-text hover:text-eco-primary transition-colors">
            Home
          </Link>
          <Link to="/category/paper" className="text-eco-text hover:text-eco-primary transition-colors">
            Paper Products
          </Link>
          <Link to="/category/wood" className="text-eco-text hover:text-eco-primary transition-colors">
            Wood Products
          </Link>
          <Link to="/category/organic" className="text-eco-text hover:text-eco-primary transition-colors">
            Organic Products
          </Link>
        </nav>
        
        <div className="flex items-center space-x-4">
          <Link to="/login">
            <Button variant="outline" className="bg-eco-background border-eco-primary text-eco-primary hover:bg-eco-primary hover:text-white">
              <User className="h-5 w-5" />
            </Button>
          </Link>
          
          <Link to="/cart">
            <Button variant="outline" className="relative bg-eco-background border-eco-primary text-eco-primary hover:bg-eco-primary hover:text-white">
              <ShoppingCart className="h-5 w-5" />
              {getCartItemCount() > 0 && (
                <span className="absolute -top-2 -right-2 bg-eco-secondary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {getCartItemCount()}
                </span>
              )}
            </Button>
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
