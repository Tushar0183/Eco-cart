
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const Hero = () => {
  return (
    <section className="relative bg-eco-highlight py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold text-eco-primary mb-4">
              Sustainable Shopping for a Greener India
            </h1>
            <p className="text-lg text-eco-text mb-8 max-w-lg">
              Discover our curated collection of eco-friendly products that help reduce your environmental footprint while supporting local artisans.
            </p>
            <div className="flex space-x-4">
              <Link to="/category/paper">
                <Button className="bg-eco-primary hover:bg-eco-secondary text-white">
                  Shop Now
                </Button>
              </Link>
              <Link to="/">
                <Button variant="outline" className="border-eco-primary text-eco-primary hover:bg-eco-primary hover:text-white">
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
          <div className="md:w-1/2 md:pl-10">
            <div className="relative rounded-lg overflow-hidden shadow-lg bg-white">
              <img 
                src="https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1374&q=80" 
                alt="Eco-friendly products" 
                className="w-full h-auto object-cover aspect-video"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                <div className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8 border-2 border-white">
                    <AvatarImage src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80" />
                    <AvatarFallback>IN</AvatarFallback>
                  </Avatar>
                  <span className="text-white text-sm font-medium">100% Sustainable Materials</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
