
import React from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useCart } from "@/contexts/CartContext";
import { Product } from "@/types/product";
import { IndianRupee } from "lucide-react";

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();

  return (
    <Card className="h-full flex flex-col overflow-hidden border border-eco-primary/10 hover:border-eco-primary/30 transition-all duration-300 hover:shadow-md">
      <Link to={`/product/${product.id}`} className="overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name} 
          className="h-48 w-full object-cover transition-transform duration-300 hover:scale-105"
        />
      </Link>
      <CardContent className="flex-grow p-4">
        <Link to={`/product/${product.id}`}>
          <h3 className="text-lg font-semibold text-eco-text hover:text-eco-primary transition-colors mb-2">{product.name}</h3>
        </Link>
        <div className="flex items-center text-lg font-bold text-eco-primary mb-2">
          <IndianRupee className="h-4 w-4 inline mr-1" />
          {product.price}
        </div>
        <p className="text-sm text-gray-600 line-clamp-3">{product.description}</p>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button 
          className="w-full bg-eco-primary hover:bg-eco-secondary text-white"
          onClick={() => addToCart(product)}
        >
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProductCard;
