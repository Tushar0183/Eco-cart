
import React from "react";
import { Link } from "react-router-dom";
import { Leaf } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-eco-primary text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <Leaf className="h-6 w-6 mr-2" />
              <span className="text-xl font-bold">EcoBazaar</span>
            </div>
            <p className="text-sm opacity-80">
              Sustainable products for a better planet. Every purchase makes a difference.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Shop</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/category/paper" className="opacity-80 hover:opacity-100 transition-opacity">
                  Paper Products
                </Link>
              </li>
              <li>
                <Link to="/category/wood" className="opacity-80 hover:opacity-100 transition-opacity">
                  Wood Products
                </Link>
              </li>
              <li>
                <Link to="/category/organic" className="opacity-80 hover:opacity-100 transition-opacity">
                  Organic Products
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="opacity-80 hover:opacity-100 transition-opacity">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/" className="opacity-80 hover:opacity-100 transition-opacity">
                  Sustainability
                </Link>
              </li>
              <li>
                <Link to="/" className="opacity-80 hover:opacity-100 transition-opacity">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Connect</h3>
            <p className="text-sm opacity-80 mb-4">
              Subscribe to our newsletter for updates on new eco-friendly products.
            </p>
          </div>
        </div>
        
        <div className="border-t border-white/20 mt-8 pt-8 text-sm opacity-70 text-center">
          <p>© 2025 EcoBazaar. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
