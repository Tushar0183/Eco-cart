
export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  category: "paper" | "wood" | "organic";
  image: string;
  quantity?: number;
  rating?: number;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  phone?: string;
  profileImage?: string;
}

export interface PaymentMethod {
  id: string;
  type: "credit" | "debit" | "upi" | "netbanking" | "wallet";
  name: string;
  lastFour?: string;
  isDefault: boolean;
}
